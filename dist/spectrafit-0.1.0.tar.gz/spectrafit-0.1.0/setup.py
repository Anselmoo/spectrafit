# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['spectrafit', 'spectrafit.test']

package_data = \
{'': ['*']}

install_requires = \
['lmfit>=1.0.2,<2.0.0',
 'matplotlib>=3.4.2,<4.0.0',
 'numpy>=1.21.1,<2.0.0',
 'openpyxl>=3.0.7,<4.0.0',
 'pandas>=1.3.0,<2.0.0',
 'scipy>=1.7.0,<2.0.0',
 'seaborn>=0.11.1,<0.12.0',
 'tqdm>=4.61.2,<5.0.0']

entry_points = \
{'console_scripts': ['spectrafit = spectrafit.spectrafit:main']}

setup_kwargs = {
    'name': 'spectrafit',
    'version': '0.1.0',
    'description': 'Fast fitting of 2D-Spectra with established routines',
    'long_description': '# spectrafit\n\nSpectraFit is a command line tool for quick data fitting based on the regular expression of distribution functions.',
    'author': 'ahahn',
    'author_email': 'Anselm.Hahn@cec.mpg.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://gitlab.gwdg.de/RIXSTools/spectrafit',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.10,<3.10',
}


setup(**setup_kwargs)
