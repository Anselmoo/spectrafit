# spectrafit

SpectraFit is a command line tool for quick data fitting based on the regular
expression of distribution functions.
