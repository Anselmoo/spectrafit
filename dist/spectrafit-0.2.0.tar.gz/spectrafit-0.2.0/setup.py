# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['spectrafit', 'spectrafit.test']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=5.4.1,<6.0.0',
 'lmfit>=1.0.2,<2.0.0',
 'matplotlib>=3.4.2,<4.0.0',
 'numdifftools>=0.9.40,<0.10.0',
 'numpy>=1.21.1,<2.0.0',
 'openpyxl>=3.0.7,<4.0.0',
 'pandas>=1.3.0,<2.0.0',
 'scipy>=1.7.0,<2.0.0',
 'seaborn>=0.11.1,<0.12.0',
 'statsmodels>=0.12.2,<0.13.0',
 'tabulate>=0.8.9,<0.9.0',
 'toml>=0.10.2,<0.11.0',
 'tqdm>=4.61.2,<5.0.0']

entry_points = \
{'console_scripts': ['spectrafit = spectrafit.spectrafit:command_line_runner']}

setup_kwargs = {
    'name': 'spectrafit',
    'version': '0.2.0',
    'description': 'Fast fitting of 2D-Spectra with established routines',
    'long_description': '# spectrafit\n\nSpectraFit is a command line tool for quick data fitting based on the regular\nexpression of distribution functions.\n',
    'author': 'ahahn',
    'author_email': 'Anselm.Hahn@cec.mpg.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://gitlab.gwdg.de/RIXSTools/spectrafit',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7.1,<3.10',
}


setup(**setup_kwargs)
